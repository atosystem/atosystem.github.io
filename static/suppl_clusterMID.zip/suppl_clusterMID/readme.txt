Clustering Results

In ./results, we show our clustering results in midi files.
Each folder contain the clustering result for each song.
Each midi file represents a cluster and we place the two-bar fragments within each cluster in the same track with a spacing of 1 bar.
